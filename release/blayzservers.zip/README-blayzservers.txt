libblayzservers.so - отдельная библиотека (не связана с libkolson).
Скачивает JSON серверов по ссылке и кладёт его в файл, который читает лаунчер.

УСТАНОВКА
  mkdir -p /storage/emulated/0/1NEIZZIR/Modules
  cp libblayzservers.so /storage/emulated/0/1NEIZZIR/Modules/
  # перезапустить лаунчер

ЧТО ПИШЕТ
  /storage/emulated/0/1NEIZZIR/servers/servers.json      - скачанный JSON
  /storage/emulated/0/1NEIZZIR/servers/_blayz_fetch.txt  - ok bytes=N | error code=-N

ПРОВЕРКА
  cat /storage/emulated/0/1NEIZZIR/servers/_blayz_fetch.txt
  head -c 200 /storage/emulated/0/1NEIZZIR/servers/servers.json

URL
  https://www.dropbox.com/scl/fi/cbse6hrwe6308xbbu5new/servers-2.json?rlkey=b1yw3qtal3xg3ppcmndziz83q&st=u5zhl7bl&dl=1

ТЕХНИЧЕСКИ
  ELF64 AArch64, soname libblayzservers.so, без DT_NEEDED и без неразрешённых
  символов. Сеть и файлы - через JNI (java.net.URL, java.io.*), поэтому HTTPS
  и редирект Dropbox работают штатно, TLS-кода в библиотеке нет. Все исключения
  Java гасятся через ExceptionCheck/ExceptionClear.

  sha256: (см. ниже, печатается при сборке)
  2b11f53cf335597505254d214553ca06ba26a49f2cad81d4b11c09e0faedfa0a
